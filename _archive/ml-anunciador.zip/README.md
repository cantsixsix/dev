# 🚀 ML Anunciador — Publicação em Massa no Mercado Livre

Publica todos os seus teclados magnéticos e periféricos no Mercado Livre via API.

## 📋 Pré-requisitos

- Node.js 18+ instalado
- App criado no ML Developers (Client ID: 4035942351678024)
- Client Secret do seu app

## ⚡ Setup Rápido

```bash
# 1. Instalar dependências
npm install

# 2. Editar o .env com seu Client Secret
# Abra .env e cole seu ML_CLIENT_SECRET

# 3. Autenticar (abre o navegador)
npm run auth

# 4. Editar fotos dos produtos em produtos.js
# Substitua "COLE_URL_DA_FOTO" pelas URLs reais

# 5. Publicar tudo!
npm run publicar

# 6. (Opcional) Ver seus anúncios
npm run listar
```

## 📁 Estrutura

```
ml-anunciador/
├── .env              ← Suas credenciais (NÃO compartilhe!)
├── auth.js           ← Autenticação OAuth2
├── produtos.js       ← Seus 12 produtos com preços e descrições
├── publicar.js       ← Script de publicação em massa
├── listar.js         ← Lista seus anúncios ativos
└── README.md         ← Este arquivo
```

## 📸 Sobre as Fotos

Você tem 2 opções pra adicionar fotos:

### Opção A: URL diretas
Suba as fotos em algum serviço (Imgur, Google Drive público, etc) e cole as URLs em `produtos.js`.

### Opção B: Upload via API
Após publicar, use a interface do ML pra adicionar fotos manualmente em cada anúncio.

## 💰 Tabela de Preços

| Produto | Qtd | Custo | Preço | Lucro/un |
|---------|-----|-------|-------|----------|
| Mad68 HE Ultimate | 7 | R$313 | R$449 | R$136 |
| ACE68 | 5 | R$272 | R$389 | R$117 |
| Epomaker Tijolo | 2 | R$215 | R$319 | R$104 |
| Fun60 | 2 | R$200 | R$299 | R$99 |
| Mars68 | 1 | R$303 | R$429 | R$126 |
| Aula F75 | 1 | R$288 | R$399 | R$111 |
| Aula Hero 68 | 1 | R$206 | R$299 | R$93 |
| ATK A8 Plus | 1 | R$181 | R$279 | R$98 |
| Machenike K500 | 1 | R$82 | R$149 | R$67 |
| Epomaker Rosa | 1 | R$120 | R$189 | R$69 |
| Rapoo MT760L | 1 | R$186 | R$279 | R$93 |
| Fone Umidigi | 1 | R$250 | R$199 | -R$51 |

**Total investido: R$5.751 | Faturamento estimado: ~R$9.200 | Lucro: ~R$3.450**

## ⚠️ Notas Importantes

- O ML cobra ~11-16% de taxa sobre vendas (dependendo do tipo de anúncio)
- Anúncio `gold_special` tem mais visibilidade mas taxa maior (~16%)
- Pode mudar pra `gold_pro` (taxa ~11%) editando `listing_type_id` em produtos.js
- As categorias podem precisar de ajuste — o script vai avisar se a categoria estiver errada
