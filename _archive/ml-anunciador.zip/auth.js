// auth.js — Autenticação OAuth2 com Mercado Livre
import 'dotenv/config';
import open from 'open';
import { createInterface } from 'readline';
import { writeFileSync, readFileSync } from 'fs';

const { ML_CLIENT_ID, ML_CLIENT_SECRET, ML_REDIRECT_URI } = process.env;

const rl = createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((res) => rl.question(q, res));

async function main() {
  console.log('\n🔐 Autenticação Mercado Livre\n');
  console.log('=' .repeat(50));

  // Step 1: Abrir URL de autorização
  const authUrl = `https://auth.mercadolivre.com.br/authorization?response_type=code&client_id=${ML_CLIENT_ID}&redirect_uri=${encodeURIComponent(ML_REDIRECT_URI)}`;

  console.log('\n📌 Passo 1: Vou abrir o navegador pra você autorizar o app.');
  console.log('Depois de autorizar, você será redirecionado pra uma URL do Google.');
  console.log('Copie o valor do "code" que aparece na URL.\n');
  console.log(`URL: ${authUrl}\n`);

  await open(authUrl);

  // Step 2: Pegar o code
  console.log('A URL vai ser algo como:');
  console.log('https://www.google.com/callback?code=TG-XXXXXXXXX-XXXXXXXX\n');

  const code = await ask('📋 Cole o code aqui (TG-...): ');

  if (!code.startsWith('TG-')) {
    console.log('❌ Code inválido. Deve começar com TG-');
    rl.close();
    return;
  }

  // Step 3: Trocar code por access_token
  console.log('\n⏳ Trocando code por access_token...\n');

  const response = await fetch('https://api.mercadolibre.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'authorization_code',
      client_id: ML_CLIENT_ID,
      client_secret: ML_CLIENT_SECRET,
      code: code.trim(),
      redirect_uri: ML_REDIRECT_URI,
    }),
  });

  const data = await response.json();

  if (data.error) {
    console.log(`❌ Erro: ${data.error} - ${data.message}`);
    rl.close();
    return;
  }

  console.log('✅ Autenticação realizada com sucesso!\n');
  console.log(`👤 User ID: ${data.user_id}`);
  console.log(`🔑 Access Token: ${data.access_token.substring(0, 20)}...`);
  console.log(`🔄 Refresh Token: ${data.refresh_token.substring(0, 20)}...`);
  console.log(`⏰ Expira em: ${data.expires_in / 3600} horas\n`);

  // Step 4: Salvar no .env
  let envContent = readFileSync('.env', 'utf-8');
  envContent = envContent.replace(/ML_ACCESS_TOKEN=.*/, `ML_ACCESS_TOKEN=${data.access_token}`);
  envContent = envContent.replace(/ML_REFRESH_TOKEN=.*/, `ML_REFRESH_TOKEN=${data.refresh_token}`);
  writeFileSync('.env', envContent);

  console.log('💾 Tokens salvos no .env automaticamente!');
  console.log('\n🚀 Agora rode: npm run publicar\n');

  rl.close();
}

main().catch(console.error);
