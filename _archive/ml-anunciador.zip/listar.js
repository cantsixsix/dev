// listar.js — Lista seus anúncios ativos no Mercado Livre
import 'dotenv/config';

const { ML_ACCESS_TOKEN } = process.env;
const API_BASE = 'https://api.mercadolibre.com';

async function main() {
  console.log('\n📋 SEUS ANÚNCIOS NO MERCADO LIVRE\n');

  if (!ML_ACCESS_TOKEN) {
    console.log('❌ Rode primeiro: npm run auth\n');
    return;
  }

  // Pegar user ID
  const userRes = await fetch(`${API_BASE}/users/me`, {
    headers: { Authorization: `Bearer ${ML_ACCESS_TOKEN}` },
  });
  const user = await userRes.json();

  if (user.error) {
    console.log('❌ Token expirado. Rode: npm run auth');
    return;
  }

  console.log(`👤 ${user.nickname} (ID: ${user.id})\n`);

  // Listar anúncios
  const itemsRes = await fetch(
    `${API_BASE}/users/${user.id}/items/search?limit=50`,
    { headers: { Authorization: `Bearer ${ML_ACCESS_TOKEN}` } }
  );
  const items = await itemsRes.json();

  if (!items.results?.length) {
    console.log('📭 Nenhum anúncio encontrado.\n');
    return;
  }

  console.log(`📦 ${items.results.length} anúncio(s) encontrado(s):\n`);
  console.log('-'.repeat(80));

  // Buscar detalhes de cada item
  for (const itemId of items.results) {
    const detRes = await fetch(`${API_BASE}/items/${itemId}`, {
      headers: { Authorization: `Bearer ${ML_ACCESS_TOKEN}` },
    });
    const det = await detRes.json();

    console.log(`ID: ${det.id}`);
    console.log(`📌 ${det.title}`);
    console.log(`💰 R$ ${det.price} | Qtd: ${det.available_quantity} | Status: ${det.status}`);
    console.log(`🔗 ${det.permalink}`);
    console.log('-'.repeat(80));
  }

  console.log('');
}

main().catch(console.error);
