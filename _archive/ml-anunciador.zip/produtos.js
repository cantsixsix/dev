// produtos.js — Seus 26 produtos prontos pra publicar
// Edite preços, descrições e URLs de fotos antes de publicar

export const produtos = [
  // ============================================
  // MAD68 HE ULTIMATE (7 unidades)
  // ============================================
  {
    title: "Teclado Magnético Mad68 HE Ultimate Hall Effect Rapid Trigger Gaming",
    category_id: "MLB420726", // Teclados - ajuste se necessário
    price: 449,
    available_quantity: 7,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special", // Anúncio premium (mais visibilidade)
    description: {
      plain_text: `🎮 Teclado Magnético Mad68 HE Ultimate — Hall Effect com Rapid Trigger

✅ DESTAQUES:
• Switches magnéticos Hall Effect — sem desgaste mecânico, vida útil superior
• Rapid Trigger — ativação instantânea, ideal pra jogos competitivos (CS2, Valorant, Osu!)
• Atuação ajustável de 0.1mm a 4.0mm — personalize a sensibilidade de cada tecla
• Layout 68 teclas (65%) — compacto, mais espaço pro mouse
• Hot-swap magnético — troque switches sem solda
• RGB por tecla — iluminação personalizável
• Conexão USB-C
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Mad68 HE Ultimate
• 1x Cabo USB-C
• 1x Manual
• Switches extras

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!

🔒 Garantia de 30 dias contra defeitos de fabricação.`
    },
    pictures: [
      // IMPORTANTE: Substitua pelas URLs das suas fotos reais
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Mad68" },
      { id: "MODEL", value_name: "HE Ultimate" },
      { id: "KEYBOARD_FORMAT", value_name: "65%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    // Metadados internos (não enviados pro ML)
    _custo: 313,
    _lucro_estimado: 136,
    _id_interno: "mad68-he",
  },

  // ============================================
  // ACE68 (5 unidades)
  // ============================================
  {
    title: "Teclado Magnético ACE68 Hall Effect Rapid Trigger Gamer Competitivo",
    category_id: "MLB420726",
    price: 389,
    available_quantity: 5,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Magnético ACE68 — Hall Effect com Rapid Trigger

✅ DESTAQUES:
• Switches magnéticos Hall Effect — precisão e durabilidade superior
• Rapid Trigger — resposta instantânea pra games competitivos
• Atuação ajustável — personalize a sensibilidade
• Layout 68 teclas (65%) — compacto e funcional
• Hot-swap magnético
• RGB por tecla personalizável
• Conexão USB-C
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado ACE68
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!

🔒 Garantia de 30 dias contra defeitos de fabricação.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "ACE" },
      { id: "MODEL", value_name: "ACE68" },
      { id: "KEYBOARD_FORMAT", value_name: "65%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 272,
    _lucro_estimado: 117,
    _id_interno: "ace68",
  },

  // ============================================
  // EPOMAKER TIJOLO (2 unidades)
  // ============================================
  {
    title: "Teclado Epomaker Tijolo Magnético Hall Effect Compacto RGB Gamer",
    category_id: "MLB420726",
    price: 319,
    available_quantity: 2,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Epomaker Tijolo — Design Compacto com Hall Effect

✅ DESTAQUES:
• Switches magnéticos Hall Effect
• Design compacto e portátil — perfeito pra setup clean
• RGB personalizável
• Conexão USB-C
• Build quality premium da Epomaker
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Epomaker Tijolo
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!

🔒 Garantia de 30 dias contra defeitos de fabricação.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Epomaker" },
      { id: "MODEL", value_name: "Tijolo" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 215,
    _lucro_estimado: 104,
    _id_interno: "epomaker-tijolo",
  },

  // ============================================
  // FUN60 (2 unidades)
  // ============================================
  {
    title: "Teclado Magnético Fun60 Hall Effect 60% Rapid Trigger Compact Gamer",
    category_id: "MLB420726",
    price: 299,
    available_quantity: 2,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Magnético Fun60 — Layout 60% Ultra Compacto

✅ DESTAQUES:
• Switches magnéticos Hall Effect com Rapid Trigger
• Layout 60% — o mais compacto, máximo espaço pro mouse
• Atuação ajustável
• RGB por tecla
• Conexão USB-C
• Ideal pra FPS competitivo (CS2, Valorant)
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Fun60
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!

🔒 Garantia de 30 dias contra defeitos de fabricação.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Fun60" },
      { id: "MODEL", value_name: "Fun60" },
      { id: "KEYBOARD_FORMAT", value_name: "60%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 200,
    _lucro_estimado: 99,
    _id_interno: "fun60",
  },

  // ============================================
  // MARS68 (1 unidade)
  // ============================================
  {
    title: "Teclado Magnético Mars68 Hall Effect Rapid Trigger 68 Teclas RGB",
    category_id: "MLB420726",
    price: 429,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Magnético Mars68 — Hall Effect Premium

✅ DESTAQUES:
• Switches magnéticos Hall Effect com Rapid Trigger
• Layout 68 teclas (65%)
• Atuação ajustável de 0.1mm a 4.0mm
• Hot-swap magnético
• RGB por tecla personalizável
• Conexão USB-C
• Build quality premium
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Mars68
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Mars" },
      { id: "MODEL", value_name: "Mars68" },
      { id: "KEYBOARD_FORMAT", value_name: "65%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 303,
    _lucro_estimado: 126,
    _id_interno: "mars68",
  },

  // ============================================
  // AULA F75 BLACK & YELLOW (1 unidade)
  // ============================================
  {
    title: "Teclado Magnético Aula F75 Hall Effect 75% Rapid Trigger Black Yellow",
    category_id: "MLB420726",
    price: 399,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Magnético Aula F75 — Layout 75% Black & Yellow

✅ DESTAQUES:
• Switches magnéticos Hall Effect com Rapid Trigger
• Layout 75% — compacto com teclas de função
• Design exclusivo Black & Yellow
• Atuação ajustável
• Hot-swap magnético
• RGB por tecla
• Gasket mount — som e digitação premium
• Conexão USB-C
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Aula F75
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Aula" },
      { id: "MODEL", value_name: "F75" },
      { id: "KEYBOARD_FORMAT", value_name: "75%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 288,
    _lucro_estimado: 111,
    _id_interno: "aula-f75",
  },

  // ============================================
  // AULA HERO 68 (1 unidade)
  // ============================================
  {
    title: "Teclado Magnético Aula Hero 68 Hall Effect Rapid Trigger RGB Gamer",
    category_id: "MLB420726",
    price: 299,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Magnético Aula Hero 68 — Hall Effect Gamer

✅ DESTAQUES:
• Switches magnéticos Hall Effect com Rapid Trigger
• Layout 68 teclas (65%)
• Atuação ajustável
• RGB por tecla
• Conexão USB-C
• Marca Aula — referência em teclados magnéticos
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Aula Hero 68
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Aula" },
      { id: "MODEL", value_name: "Hero 68" },
      { id: "KEYBOARD_FORMAT", value_name: "65%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 206,
    _lucro_estimado: 93,
    _id_interno: "aula-hero-68",
  },

  // ============================================
  // ATK A8 PLUS (1 unidade)
  // ============================================
  {
    title: "Teclado Magnético ATK A8 Plus Hall Effect Rapid Trigger Gaming RGB",
    category_id: "MLB420726",
    price: 279,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Magnético ATK A8 Plus — Hall Effect

✅ DESTAQUES:
• Switches magnéticos Hall Effect com Rapid Trigger
• Atuação ajustável
• RGB por tecla
• Conexão USB-C
• Build quality sólida
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado ATK A8 Plus
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "ATK" },
      { id: "MODEL", value_name: "A8 Plus" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 181,
    _lucro_estimado: 98,
    _id_interno: "atk-a8-plus",
  },

  // ============================================
  // MACHENIKE K500 B64 (1 unidade)
  // ============================================
  {
    title: "Teclado Mecânico Machenike K500 B64 Compacto 64 Teclas RGB Gamer",
    category_id: "MLB420726",
    price: 149,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎮 Teclado Mecânico Machenike K500 B64 — Compacto 64 Teclas

✅ DESTAQUES:
• Layout 64 teclas — ultra compacto
• Switches mecânicos de qualidade
• RGB por tecla
• Conexão USB-C
• Design premium Machenike
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Machenike K500 B64
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Machenike" },
      { id: "MODEL", value_name: "K500 B64" },
      { id: "KEYBOARD_FORMAT", value_name: "60%" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 82,
    _lucro_estimado: 67,
    _id_interno: "machenike-k500",
  },

  // ============================================
  // EPOMAKER ROSA (1 unidade)
  // ============================================
  {
    title: "Teclado Epomaker Rosa Mecânico Compacto RGB Pink Kawaii Gamer",
    category_id: "MLB420726",
    price: 189,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🌸 Teclado Epomaker Rosa — Design Fofo e Funcional

✅ DESTAQUES:
• Design Rosa/Pink exclusivo — perfeito pra setups coloridos
• Switches mecânicos de qualidade Epomaker
• RGB personalizável
• Compacto e portátil
• Conexão USB-C
• Ideal pra quem busca estética e performance
• Compatível com Windows/Mac

📦 CONTEÚDO DA EMBALAGEM:
• 1x Teclado Epomaker Rosa
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Epomaker" },
      { id: "MODEL", value_name: "Rosa" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 120,
    _lucro_estimado: 69,
    _id_interno: "epomaker-rosa",
  },

  // ============================================
  // RAPOO MT760L MOUSE (1 unidade)
  // ============================================
  {
    title: "Mouse Ergonômico Rapoo MT760L Sem Fio Bluetooth Programável Escritório",
    category_id: "MLB1714", // Mouse - ajuste se necessário
    price: 279,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🖱️ Mouse Ergonômico Rapoo MT760L Light Black — Sem Fio

✅ DESTAQUES:
• Design ergonômico — conforto pra longas horas de uso
• Conexão Bluetooth + 2.4GHz + USB-C (3 modos)
• Sensor de alta precisão
• Botões programáveis
• Bateria recarregável de longa duração
• Ideal pra escritório e produtividade
• Compatível com Windows/Mac/Linux

📦 CONTEÚDO DA EMBALAGEM:
• 1x Mouse Rapoo MT760L
• 1x Receptor USB 2.4GHz
• 1x Cabo USB-C
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Rapoo" },
      { id: "MODEL", value_name: "MT760L" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 186,
    _lucro_estimado: 93,
    _id_interno: "rapoo-mt760l",
  },

  // ============================================
  // FONE UMIDIGI (1 unidade)
  // ============================================
  {
    title: "Fone de Ouvido Umidigi Bluetooth Sem Fio TWS com Estojo de Carga",
    category_id: "MLB1152", // Fones - ajuste se necessário
    price: 199,
    available_quantity: 1,
    condition: "new",
    currency_id: "BRL",
    buying_mode: "buy_it_now",
    listing_type_id: "gold_special",
    description: {
      plain_text: `🎧 Fone Bluetooth Umidigi — TWS Sem Fio

✅ DESTAQUES:
• Bluetooth 5.0+ — conexão estável
• TWS (True Wireless Stereo)
• Estojo de carga portátil
• Cancelamento de ruído
• Microfone integrado pra chamadas
• Resistente à água (IPX)
• Compatível com Android/iOS

📦 CONTEÚDO DA EMBALAGEM:
• 1x Par de fones Umidigi
• 1x Estojo de carga
• 1x Cabo de carga
• Ponteiras extras
• 1x Manual

⚡ ENVIO RÁPIDO — Produto no Brasil, pronta entrega!
🔒 Garantia de 30 dias.`
    },
    pictures: [
      { source: "https://COLE_URL_DA_FOTO_1.jpg" },
      { source: "https://COLE_URL_DA_FOTO_2.jpg" },
    ],
    attributes: [
      { id: "BRAND", value_name: "Umidigi" },
      { id: "ITEM_CONDITION", value_name: "Novo" },
    ],
    _custo: 250,
    _lucro_estimado: -51,
    _id_interno: "fone-umidigi",
  },
];

// Resumo do estoque
export function resumoEstoque() {
  let totalCusto = 0;
  let totalVenda = 0;
  let totalQtd = 0;

  console.log('\n📦 RESUMO DO ESTOQUE\n');
  console.log('='.repeat(70));
  console.log(
    'Produto'.padEnd(30),
    'Qtd'.padStart(4),
    'Custo'.padStart(10),
    'Preço'.padStart(10),
    'Lucro'.padStart(10)
  );
  console.log('-'.repeat(70));

  for (const p of produtos) {
    const lucro = (p.price - p._custo) * p.available_quantity;
    totalCusto += p._custo * p.available_quantity;
    totalVenda += p.price * p.available_quantity;
    totalQtd += p.available_quantity;

    console.log(
      p._id_interno.padEnd(30),
      String(p.available_quantity).padStart(4),
      `R$${p._custo}`.padStart(10),
      `R$${p.price}`.padStart(10),
      `R$${lucro}`.padStart(10)
    );
  }

  console.log('='.repeat(70));
  console.log(
    'TOTAL'.padEnd(30),
    String(totalQtd).padStart(4),
    `R$${totalCusto}`.padStart(10),
    `R$${totalVenda}`.padStart(10),
    `R$${totalVenda - totalCusto}`.padStart(10)
  );
  console.log('');
}
