// publicar.js — Publica todos os produtos no Mercado Livre
import 'dotenv/config';
import { produtos, resumoEstoque } from './produtos.js';

const { ML_ACCESS_TOKEN } = process.env;
const API_BASE = 'https://api.mercadolibre.com';

// Delay entre requests pra não tomar rate limit
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function refreshToken() {
  const { ML_CLIENT_ID, ML_CLIENT_SECRET, ML_REFRESH_TOKEN } = process.env;

  const res = await fetch(`${API_BASE}/oauth/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'refresh_token',
      client_id: ML_CLIENT_ID,
      client_secret: ML_CLIENT_SECRET,
      refresh_token: ML_REFRESH_TOKEN,
    }),
  });

  const data = await res.json();
  if (data.access_token) {
    console.log('🔄 Token renovado com sucesso!');
    return data.access_token;
  }
  throw new Error(`Erro ao renovar token: ${JSON.stringify(data)}`);
}

async function verificarCategoria(categoryId, token) {
  const res = await fetch(`${API_BASE}/categories/${categoryId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const data = await res.json();
  return data;
}

async function buscarAtributosObrigatorios(categoryId, token) {
  const res = await fetch(
    `${API_BASE}/categories/${categoryId}/attributes`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  const data = await res.json();
  const obrigatorios = data.filter((a) => a.tags?.required);
  return obrigatorios;
}

async function publicarProduto(produto, token) {
  // Remove campos internos antes de enviar
  const { _custo, _lucro_estimado, _id_interno, ...payload } = produto;

  const res = await fetch(`${API_BASE}/items`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = await res.json();
  return data;
}

async function main() {
  console.log('\n🚀 ANUNCIADOR MERCADO LIVRE — Publicação em Massa\n');

  // Verificar token
  if (!ML_ACCESS_TOKEN) {
    console.log('❌ Access token não encontrado!');
    console.log('   Rode primeiro: npm run auth\n');
    return;
  }

  let token = ML_ACCESS_TOKEN;

  // Testar se o token é válido
  const testRes = await fetch(`${API_BASE}/users/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const user = await testRes.json();

  if (user.error) {
    console.log('⚠️  Token expirado, tentando renovar...');
    try {
      token = await refreshToken();
    } catch (e) {
      console.log('❌ Não foi possível renovar o token. Rode: npm run auth');
      return;
    }
  }

  console.log(`✅ Logado como: ${user.nickname || user.first_name} (ID: ${user.id})\n`);

  // Mostrar resumo
  resumoEstoque();

  // Publicar cada produto
  const resultados = [];
  let sucesso = 0;
  let erros = 0;

  for (let i = 0; i < produtos.length; i++) {
    const produto = produtos[i];
    console.log(`\n📤 [${i + 1}/${produtos.length}] Publicando: ${produto._id_interno}...`);

    // Verificar se as fotos foram preenchidas
    const temFotoReal = produto.pictures.some(
      (p) => !p.source.includes('COLE_URL')
    );
    if (!temFotoReal) {
      console.log(`   ⚠️  PULADO — Fotos não preenchidas! Edite produtos.js`);
      erros++;
      resultados.push({
        produto: produto._id_interno,
        status: 'PULADO',
        motivo: 'Fotos não preenchidas',
      });
      continue;
    }

    try {
      const resultado = await publicarProduto(produto, token);

      if (resultado.id) {
        sucesso++;
        const link = resultado.permalink;
        console.log(`   ✅ Publicado! ID: ${resultado.id}`);
        console.log(`   🔗 ${link}`);
        resultados.push({
          produto: produto._id_interno,
          status: 'OK',
          ml_id: resultado.id,
          link,
        });
      } else {
        erros++;
        const msg = resultado.cause?.[0]?.message || resultado.message || JSON.stringify(resultado);
        console.log(`   ❌ Erro: ${msg}`);
        resultados.push({
          produto: produto._id_interno,
          status: 'ERRO',
          motivo: msg,
        });
      }
    } catch (err) {
      erros++;
      console.log(`   ❌ Erro de rede: ${err.message}`);
      resultados.push({
        produto: produto._id_interno,
        status: 'ERRO',
        motivo: err.message,
      });
    }

    // Esperar 2 segundos entre cada publicação
    if (i < produtos.length - 1) {
      await delay(2000);
    }
  }

  // Resumo final
  console.log('\n' + '='.repeat(50));
  console.log('📊 RESUMO DA PUBLICAÇÃO');
  console.log('='.repeat(50));
  console.log(`✅ Sucesso: ${sucesso}`);
  console.log(`❌ Erros: ${erros}`);
  console.log(`📦 Total: ${produtos.length}\n`);

  // Salvar log
  const logFile = `publicacao_${new Date().toISOString().slice(0, 10)}.json`;
  const { writeFileSync } = await import('fs');
  writeFileSync(logFile, JSON.stringify(resultados, null, 2));
  console.log(`📝 Log salvo em: ${logFile}\n`);
}

main().catch(console.error);
